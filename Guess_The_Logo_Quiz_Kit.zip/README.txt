GUESS THE LOGO QUIZ KIT

Contents:
- index.html: public quiz, 4-option mode + Hard Mode (type brand name)
- logos.json: 12 starter questions
- CreatorStudio.html: local editor to add/edit/delete logo questions and export logos.json
- Keep CreatorStudio.html private; never upload it to the public repo.

IMPORTANT: The starter cards use symbol-style placeholders rather than official logo images. Use images you have permission to use. A local Creator Studio is not a secure online admin and cannot automatically publish changes; upload its exported logos.json to GitHub to publish.

Publish on mobile:
1. Open https://github.com/Armantariq/Memesound-funnyquiz
2. Back up the existing index.html before replacing it.
3. Upload/replace index.html from this kit.
4. Upload logos.json to the same repository root.
5. Commit both files to branch main.
6. Wait 1–3 minutes, then open https://armantariq.github.io/Memesound-funnyquiz/

Studio:
Open CreatorStudio.html on your phone in a browser. Add brand name, category and an image, then export logos.json. Export a backup regularly because data is held locally in the open page. The editor does not have a password and should not be published.
